﻿namespace Forecast
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCapture = new System.Windows.Forms.Button();
            this.btnReport1 = new System.Windows.Forms.Button();
            this.btnReport2 = new System.Windows.Forms.Button();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblMinTemp = new System.Windows.Forms.Label();
            this.lblMaxTemp = new System.Windows.Forms.Label();
            this.lblPrecip = new System.Windows.Forms.Label();
            this.lblHumid = new System.Windows.Forms.Label();
            this.lblWindSpd = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ddMinTemp = new System.Windows.Forms.NumericUpDown();
            this.ddMaxTemp = new System.Windows.Forms.NumericUpDown();
            this.ddPrecipitation = new System.Windows.Forms.NumericUpDown();
            this.ddWindSpeed = new System.Windows.Forms.NumericUpDown();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.ddHumidity = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ddMinTemp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddMaxTemp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddPrecipitation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddWindSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddHumidity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCapture
            // 
            this.btnCapture.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCapture.Location = new System.Drawing.Point(15, 562);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(121, 38);
            this.btnCapture.TabIndex = 0;
            this.btnCapture.Text = "Capture";
            this.btnCapture.UseVisualStyleBackColor = true;
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click_1);
            // 
            // btnReport1
            // 
            this.btnReport1.Location = new System.Drawing.Point(393, 571);
            this.btnReport1.Name = "btnReport1";
            this.btnReport1.Size = new System.Drawing.Size(116, 23);
            this.btnReport1.TabIndex = 1;
            this.btnReport1.Text = "Generate Report 1";
            this.btnReport1.UseVisualStyleBackColor = true;
            this.btnReport1.Click += new System.EventHandler(this.btnDetails_Click_1);
            // 
            // btnReport2
            // 
            this.btnReport2.Location = new System.Drawing.Point(538, 571);
            this.btnReport2.Name = "btnReport2";
            this.btnReport2.Size = new System.Drawing.Size(108, 23);
            this.btnReport2.TabIndex = 2;
            this.btnReport2.Text = "Generate Report 2";
            this.btnReport2.UseVisualStyleBackColor = true;
            this.btnReport2.Click += new System.EventHandler(this.btnReport2_Click);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(282, 55);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(24, 13);
            this.lblCity.TabIndex = 3;
            this.lblCity.Text = "City";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(282, 114);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 4;
            this.lblDate.Text = "Date";
            // 
            // lblMinTemp
            // 
            this.lblMinTemp.AutoSize = true;
            this.lblMinTemp.Location = new System.Drawing.Point(282, 185);
            this.lblMinTemp.Name = "lblMinTemp";
            this.lblMinTemp.Size = new System.Drawing.Size(87, 13);
            this.lblMinTemp.TabIndex = 5;
            this.lblMinTemp.Text = "Min Temperature";
            // 
            // lblMaxTemp
            // 
            this.lblMaxTemp.AutoSize = true;
            this.lblMaxTemp.Location = new System.Drawing.Point(282, 285);
            this.lblMaxTemp.Name = "lblMaxTemp";
            this.lblMaxTemp.Size = new System.Drawing.Size(90, 13);
            this.lblMaxTemp.TabIndex = 6;
            this.lblMaxTemp.Text = "Max Temperature";
            // 
            // lblPrecip
            // 
            this.lblPrecip.AutoSize = true;
            this.lblPrecip.Location = new System.Drawing.Point(282, 384);
            this.lblPrecip.Name = "lblPrecip";
            this.lblPrecip.Size = new System.Drawing.Size(65, 13);
            this.lblPrecip.TabIndex = 7;
            this.lblPrecip.Text = "Precipitation";
            this.lblPrecip.Click += new System.EventHandler(this.lblPrecip_Click);
            // 
            // lblHumid
            // 
            this.lblHumid.AutoSize = true;
            this.lblHumid.Location = new System.Drawing.Point(282, 443);
            this.lblHumid.Name = "lblHumid";
            this.lblHumid.Size = new System.Drawing.Size(47, 13);
            this.lblHumid.TabIndex = 8;
            this.lblHumid.Text = "Humidity";
            // 
            // lblWindSpd
            // 
            this.lblWindSpd.AutoSize = true;
            this.lblWindSpd.BackColor = System.Drawing.SystemColors.Control;
            this.lblWindSpd.Location = new System.Drawing.Point(12, 521);
            this.lblWindSpd.Name = "lblWindSpd";
            this.lblWindSpd.Size = new System.Drawing.Size(66, 13);
            this.lblWindSpd.TabIndex = 9;
            this.lblWindSpd.Text = "Wind Speed";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd MMMM yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(404, 107);
            this.dateTimePicker1.MaxDate = new System.DateTime(2450, 12, 31, 0, 0, 0, 0);
            this.dateTimePicker1.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(150, 20);
            this.dateTimePicker1.TabIndex = 18;
            // 
            // ddMinTemp
            // 
            this.ddMinTemp.Location = new System.Drawing.Point(404, 183);
            this.ddMinTemp.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ddMinTemp.Name = "ddMinTemp";
            this.ddMinTemp.Size = new System.Drawing.Size(120, 20);
            this.ddMinTemp.TabIndex = 19;
            // 
            // ddMaxTemp
            // 
            this.ddMaxTemp.Location = new System.Drawing.Point(404, 278);
            this.ddMaxTemp.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ddMaxTemp.Name = "ddMaxTemp";
            this.ddMaxTemp.Size = new System.Drawing.Size(120, 20);
            this.ddMaxTemp.TabIndex = 20;
            // 
            // ddPrecipitation
            // 
            this.ddPrecipitation.Location = new System.Drawing.Point(404, 377);
            this.ddPrecipitation.Name = "ddPrecipitation";
            this.ddPrecipitation.Size = new System.Drawing.Size(120, 20);
            this.ddPrecipitation.TabIndex = 21;
            // 
            // ddWindSpeed
            // 
            this.ddWindSpeed.Location = new System.Drawing.Point(128, 519);
            this.ddWindSpeed.Name = "ddWindSpeed";
            this.ddWindSpeed.Size = new System.Drawing.Size(120, 20);
            this.ddWindSpeed.TabIndex = 22;
            // 
            // cmbCity
            // 
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Items.AddRange(new object[] {
            "Johannesburg",
            "Cape Town",
            "Pretoria",
            "Durban",
            "Port Elizabeth",
            "East London",
            "Polokwane",
            "Bloemfontein",
            "Rustenburg",
            "Mbombela",
            "Stellenbosch",
            "Kimberley",
            "Richards Bay"});
            this.cmbCity.Location = new System.Drawing.Point(404, 47);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(121, 21);
            this.cmbCity.TabIndex = 23;
            this.cmbCity.Text = "City";
            // 
            // ddHumidity
            // 
            this.ddHumidity.Location = new System.Drawing.Point(404, 436);
            this.ddHumidity.Name = "ddHumidity";
            this.ddHumidity.Size = new System.Drawing.Size(120, 20);
            this.ddHumidity.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 36);
            this.label1.TabIndex = 25;
            this.label1.Text = "Wheather forecast capture";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Forecast.Properties.Resources.www23;
            this.pictureBox2.Location = new System.Drawing.Point(26, 246);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(231, 173);
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Forecast.Properties.Resources.wwwww12;
            this.pictureBox1.Location = new System.Drawing.Point(26, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 151);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(670, 606);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ddHumidity);
            this.Controls.Add(this.cmbCity);
            this.Controls.Add(this.ddWindSpeed);
            this.Controls.Add(this.ddPrecipitation);
            this.Controls.Add(this.ddMaxTemp);
            this.Controls.Add(this.ddMinTemp);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblWindSpd);
            this.Controls.Add(this.lblHumid);
            this.Controls.Add(this.lblPrecip);
            this.Controls.Add(this.lblMaxTemp);
            this.Controls.Add(this.lblMinTemp);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.btnReport2);
            this.Controls.Add(this.btnReport1);
            this.Controls.Add(this.btnCapture);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ddMinTemp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddMaxTemp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddPrecipitation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddWindSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddHumidity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.Button btnReport1;
        private System.Windows.Forms.Button btnReport2;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblDate;
  
        private System.Windows.Forms.Label lblMinTemp;
        private System.Windows.Forms.Label lblMaxTemp;
        private System.Windows.Forms.Label lblPrecip;
        private System.Windows.Forms.Label lblHumid;
        private System.Windows.Forms.Label lblWindSpd;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.NumericUpDown ddMinTemp;
        private System.Windows.Forms.NumericUpDown ddMaxTemp;
        private System.Windows.Forms.NumericUpDown ddPrecipitation;
        private System.Windows.Forms.NumericUpDown ddWindSpeed;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.NumericUpDown ddHumidity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

