﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forecast
{
    public class Forecasting
    {
        private string city;

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private string minTemp;

        public string MinTemp
        {
            get { return minTemp; }
            set { minTemp = value; }
        }

        private string maxTemp;

        public string MaxTemp
        {
            get { return maxTemp; }
            set { maxTemp = value; }
        }

        private string precipitation;

        public string Precipitation
        {
            get { return precipitation; }
            set { precipitation = value; }
        }

        private string humidity;

        public string Humidity
        {
            get { return humidity; }
            set { humidity = value; }
        }

        private string windSpeed;

        public string WindSpeed
        {
            get { return windSpeed; }
            set { windSpeed = value; }
        }
        public Forecasting(string cty, DateTime day, string mntemp, string mxtemp, string precip, string Humid, string wndSpeed)
        {
            city = cty;
            date = day;
            minTemp = mntemp;
            maxTemp = mxtemp;
            precipitation = precip;
            humidity = Humid;
            windSpeed = wndSpeed;
        }

        public override string ToString()
        {
            return city + " " + date.ToString("dd MMMM yyyy") + " " + minTemp + " " + maxTemp + " " + precipitation + "% " + humidity + "% " + windSpeed+" Km/h";
        }
    }

}
    

