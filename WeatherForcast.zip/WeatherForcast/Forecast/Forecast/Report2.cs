﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forecast
{
    public partial class Report2 : Form
    {
        public List<Forecasting> forecasts;
        public List<String> cities = new List<string>();
        public Report2(List<Forecasting> forecasts)
        {
            this.forecasts = forecasts;
            InitializeComponent();
        }

        private void Report2_Load(object sender, EventArgs e)
        {

        }
        private void printData(String city, DateTime startDate, DateTime endDate)
        {
            List<Forecasting> tempList = new List<Forecasting>();

            foreach (Forecasting forecast in this.forecasts)
            {
                if (forecast.City.Equals(city) && DateTime.Compare(forecast.Date, startDate) >= 0 && DateTime.Compare(forecast.Date, endDate) <= 0)
                {
                    tempList.Add(forecast);
                }
            }

            //find min temp
            int minTempIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].MinTemp) <= Convert.ToInt32(tempList[minTempIndex].MinTemp))
                {
                    minTempIndex = i;
                }
            }

            //find max temp
            int maxTempIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].MaxTemp) >= Convert.ToInt32(tempList[minTempIndex].MaxTemp))
                {
                    maxTempIndex = i;
                }
            }

            //find min precipitation
            int minPrecIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].Precipitation) <= Convert.ToInt32(tempList[minTempIndex].Precipitation))
                {
                    minPrecIndex = i;
                }
            }

            //find max temp
            int maxPrecIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].Precipitation) >= Convert.ToInt32(tempList[minTempIndex].Precipitation))
                {
                    maxPrecIndex = i;
                }
            }

            //find min humidity
            int minHumidIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].Humidity) <= Convert.ToInt32(tempList[minTempIndex].Humidity))
                {
                    minHumidIndex = i;
                }
            }

            //find max temp
            int maxHumidIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].Humidity) >= Convert.ToInt32(tempList[minTempIndex].Humidity))
                {
                    maxHumidIndex = i;
                }
            }

            //find min wind speed
            int minWSIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].WindSpeed) <= Convert.ToInt32(tempList[minTempIndex].WindSpeed))
                {
                    minWSIndex = i;
                }
            }

            //find max wind speed
            int maxWSIndex = 0;
            for (int i = 1; i < tempList.Count; i++)
            {
                if (Convert.ToInt32(tempList[i].WindSpeed) >= Convert.ToInt32(tempList[minTempIndex].WindSpeed))
                {
                    maxWSIndex = i;
                }
            }




            if (tempList.Count >= 1)
            {
                richTextBox1.AppendText(city+ ": \n");
                richTextBox1.AppendText("Date\t\tMinimum Temperature\t\tMaximum Temperature\t\tPrecipitation\t\tHumidity\t\tWind Speed\n\n");
                for (int i = 0; i < tempList.Count; i++)
                {

                    Forecasting f = tempList[i];
                    richTextBox1.AppendText(f.Date.ToString("dd MMMM yyyy") + "\t\t");

                    if (i == minTempIndex)
                    {
                        richTextBox1.SelectionColor = Color.Blue;
                        richTextBox1.SelectedText = f.MinTemp;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else
                    {
                        richTextBox1.AppendText(f.MinTemp);
                    }

                    richTextBox1.AppendText("\t\t\t\t");

                    if (i == maxTempIndex)
                    {
                        richTextBox1.SelectionColor = Color.Red;
                        richTextBox1.SelectedText = f.MaxTemp;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else
                    {
                        richTextBox1.AppendText(f.MaxTemp);
                    }
                    richTextBox1.AppendText("\t\t\t");

                    if (i == minPrecIndex)
                    {
                        richTextBox1.SelectionColor = Color.Blue;
                        richTextBox1.SelectedText = f.Precipitation;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else if (i == maxPrecIndex)
                    {
                        richTextBox1.SelectionColor = Color.Red;
                        richTextBox1.SelectedText = f.Precipitation;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else
                    {
                        richTextBox1.AppendText(f.Precipitation);
                    }

                    richTextBox1.AppendText(" %\t\t\t");

                    if (i == minHumidIndex)
                    {
                        richTextBox1.SelectionColor = Color.Blue;
                        richTextBox1.SelectedText = f.Humidity;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else if (i == maxHumidIndex)
                    {
                        richTextBox1.SelectionColor = Color.Red;
                        richTextBox1.SelectedText = f.Humidity;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else
                    {
                        richTextBox1.AppendText(f.Humidity);
                    }

                    richTextBox1.AppendText(" %\t\t\t");

                    if (i == minWSIndex)
                    {
                        richTextBox1.SelectionColor = Color.Blue;
                        richTextBox1.SelectedText = f.WindSpeed;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else if (i == maxWSIndex)
                    {
                        richTextBox1.SelectionColor = Color.Red;
                        richTextBox1.SelectedText = f.WindSpeed;
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    else
                    {
                        richTextBox1.AppendText(f.WindSpeed);
                    }


                    richTextBox1.AppendText(" Km/h");




                    richTextBox1.AppendText("\n");
                }

            }
            else
            {
                richTextBox1.AppendText("No data found for city: " + city + " for the selected date range\n\n");
            }



          
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            String sCity;
            foreach (Object item in checkedListBox1.CheckedItems)
            {
                sCity = item as String;
                cities.Add(sCity);
                
            }
            DateTime startDate = dateTimePicker1.Value;
            DateTime endDate = dateTimePicker2.Value;

           
            foreach (String city in cities)
            {
                printData(city, startDate, endDate);
              
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
