﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forecast
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string SetCityValue = "";
        public static string SetDateValue = "";
        public static string SetMinTempValue = "";
        public static string SetMaxTempValue = "";
        public static string SetPrecipitationValue = "";
        public static string SetHumidityValue = "";
        public static string SetWindSpeedValue = "";
        List<Forecasting> forecastsList = new List<Forecasting>();

      
        private void btnCapture_Click_1(object sender, EventArgs e)
        {
            Forecasting forecasts = new Forecasting(cmbCity.Text, dateTimePicker1.Value, Convert.ToString(ddMinTemp.Value), Convert.ToString(ddMaxTemp.Value), Convert.ToString(ddPrecipitation.Value),
                Convert.ToString(ddHumidity.Value), Convert.ToString(ddWindSpeed.Value));
            // lstCapturedForecast.Items.Add(forecasts.ToString());
            forecastsList.Add(forecasts);
            /*   SetCityValue = txtCity.Text;
               SetDateValue = dateTimePicker1.Value.ToString("dd MMMM yyyy");
               SetMinTempValue = txtMinTemp.Text;
               SetMaxTempValue = txtMaxTemp.Text;
               SetPrecipitationValue = txtPrecipitation.Text;
               SetHumidityValue = txtHumidity.Text;
               SetWindSpeedValue = txtWindSpeed.Text;
               c.Clear();
               txtMaxTemp.Clear();
               txtMaxTemp.Clear();
               txtPrecipitation.Clear();
               txtHumidity.Clear();
               txtWindSpeed.Clear();*/
            cmbCity.SelectedIndex = -1;
            cmbCity.Text = "City";
            ddMinTemp.Value = 0;
            ddMaxTemp.Value = 0;
            ddPrecipitation.Value = 0;
            ddHumidity.Value = 0;
            ddWindSpeed.Value = 0;
            printCaptured();
        
        }
        //to be deleted
        private void printCaptured()
        {
            foreach (Forecasting f in forecastsList)
            {
                Console.WriteLine(f.ToString());
            }
        }
      
        private void btnDetails_Click_1(object sender, EventArgs e)
        {

            Form detailsForm = new DetailsForm(this.forecastsList);
            detailsForm.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReport2_Click(object sender, EventArgs e)
        {
            var report2 = new Report2(this.forecastsList);
            
                report2.Show();
            
           
        }

        private void lblPrecip_Click(object sender, EventArgs e)
        {

        }
    }

}

      
    

